#include <stdio.h>
#include <stdlib.h>

void ex7_2b()
{
	int num[10], i;
	for (i = 0; i < 10; i++)
	{
		printf("num[%d]=%p,num[%d]+1=%p", i, &num[i], i, &num[i] + 1);
		printf("\n");
	}
	//system("pause");
	//return 0;
}