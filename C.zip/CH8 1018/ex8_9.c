#include <stdio.h>
#include <stdlib.h>

void ex8_9()
{
	//char *a[4] = { "Department", "of", "Information", "Management" };
	char *a[] = { "ab", "cd","ef", "gh","ij", "kl","mn","op","qr","st","uv","wx","yz" };
	printf("*a = %p\n", *a);
	printf("**a = %c\n", **a);

	printf("*(a+2) = %p\n", *(a+2));
	printf("**(a+2) = %c\n", **(a + 2));
	printf("\n");
	printf("*(*(a+1)+0) = %c\n", *(*(a + 1) + 0));
	printf("*(*(a+1)+1) = %c\n", *(*(a + 1) + 1));
	printf("*(*(a+1)+2) = %c\n", *(*(a + 1) + 2));
	printf("\n");
	printf("*a+2 = %p\n", *a + 2);
	printf("*(*a+2) = %c\n", *(*a + 2));
	printf("\n");
	printf("(*(a+2)+0) = %p\n", (*(a + 2) + 0));
	printf("(*(a+2)+1) = %p\n", (*(a + 2) + 1));
	printf("\n");
	for (int i = 0; i < 13; i++)
	{
		for (int y = 0; y < 2; y++)
		{
			printf("%c\t", *(*(a + i)+y));
			printf("%p\n", (*(a + i) + y));
		}
		printf("\n");
	}
}