#include <stdio.h>
#include <stdlib.h>
void ex8_6()
{
	double d;
	double *p = &d;
	double **pp = &p;
	printf("�п�J�@double��: ");		
	scanf("%Lf", &d);
	printf("d=%.2f, *p=%.2Lf, and **pp=%.2Lf\n", d, *p, **pp);
	//system("PAUSE");
	//return 0;
}
