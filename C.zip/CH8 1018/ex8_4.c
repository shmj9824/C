#include <stdio.h>
#include <stdlib.h>

void ex8_4()
{
	int a = 100;
	int *p1 = &a;
	int **p2 = &p1;
	int ***p3 = &p2;
	printf("&a=%p , a=%d\n", &a, a);
	printf("&p1=%p , p1=%p\n", &p1, p1);
	printf("&p2=%p , p2=%p\n", &p2, p2);
	printf("&p3=%p , p3=%p\n", &p3, p3);
	printf("*p1=%d , **p2=%d , ***p3=%d\n", *p1, **p2,***p3);
	printf("p1��%d��Bytes,p2��%d��Bytes,p3��%d��Bytes\n", sizeof(p1), sizeof(p2), sizeof(p3));
}