#include <stdio.h>
#include <stdlib.h>

//�����m��
void ex8_5()
{
	/*int a = 100;
	int *p = a;
	int **pp = p;
	printf("a=%d, *p=%and **pp=%d", a, *p, **pp);
	return 0;*/
	int a = 100;
	int *p = &a;
	int **pp = &p;
	printf("a=%d, *p=%d and **pp=%d\n", a, *p, **pp);
	return 0;
}