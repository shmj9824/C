#include <stdio.h>
#include <stdlib.h>
void Hw1()
{
	printf("Hello Every One, Welcome to the C World!\n");
	//system("pause");
	//return 0;
}