#include <stdio.h>
#include <stdlib.h>
void ex1_1()
{
	printf("Hello C!\n");
	printf("Hello World!\n");
	//system("pause");
	//return 0;
}