#include <stdio.h>
#include <stdlib.h>

void ex1_5()
{
	int i;
	for (i = 0; i <= 2; i++)
	{
		printf("Cats are Running, ");
		printf("Dogs are Chasing.\n");
	}
	//system("pause");
	//return 0;
}

/*#include <stdio.h>
#include <stdlib.h>
void ex1_5()
{
int i;
for (i = 0; i <= 2; i++)
{
printf("Cats are Running, ");
printf("Dogs are Chasing.\n");
}
system("pause");
return 0;
}*/