#include <stdio.h>
#include <stdlib.h>
void Hw2()
{
	char x1 = 'a', x2 = 'b', x3 = 'n';
	printf("%c%c%c%c%c%c\n", x2, x1, x3, x1, x3, x1);
	//system("pause");
	//return 0;
}