#include <stdio.h>
#include <stdlib.h> 
void Hw3()
{
	int sum = 0;
	int i;
	for (i = 1; i<101; i = i + 2)
	{
		sum = sum + i;
	}
	printf("1+3+5+�K+99=%d\n", sum);
	//system("pause");
	//return 0;
}