#include <stdio.h>
#include <stdlib.h>
void Hw4()
{
	int i = 1;
	int sum = 0;
	for (i = 1; i<11; i++)
	{
		sum = sum + i*i;
	}
	printf("1^2+2^2+3^2+�K+10^2=%d\n", sum);
	//system("pause");
	//return 0;
}