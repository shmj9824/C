#include <stdio.h>
#include <stdlib.h>

void Star()
{
	int h, w,j,in1,input;
	printf("�ЦC�L�P�P���:");	scanf("%d", &in1);
	//printf("�˦�1.�ѥk�W�쥪�U�A2.�ѥ��W��k�U�A3.�ѥ��U��k�W�A4.�ѥk�U�쥪�W�A5.�Ѥ��ߦV�U\n");
	//printf("�п�ܦC�L�˦�:");	scanf("%d", &input);


			for (w = 1; w <= in1; w++)
			{
				for (h = 1; h <= in1 - w; h++)
				{
					printf(" ");
				}
				for (j = 1; j <= w; j++)
					printf("*");
				printf("\n");
			}
		printf("\n");
			for (w = 1; w <= in1; w++)
			{
				for (h = 1; h <= w; h++)
					printf("*");
				printf("\n");
			}

		printf("\n");
		for (w = 1; w <= in1; w++)
		{
			for (h = in1 - w; h >= 0; h--)
				printf("*");
			printf(" ");
			printf("\n");
		}
	
	printf("\n");

	for (w = 1; w <= in1; w++)
	{
		for (j = 2; j <= w; j++)
		{
			printf(" ");
		}
		for (h = 0; h <= in1-w; h++)
			printf("*");
		printf("\n");
	}

	printf("\n");

	for (w = 1; w <= in1; w++)
	{
		for (h = 1; h <= in1 - w; h++)
		{
			printf(" ");
		}
		for (j = 1; j<= w*2-1; j++)
			printf("*");
		printf("\n");
	}
	
	//system("pause");
	//return 0;

}