#include <stdio.h>
#include <stdlib.h>
void CtoF()
{
	int c, F;
	printf("�п�J���ū�:");
	scanf("%d", &c);
	F = 1.8*c + 32;
	printf("\n�ؤ�ū׬�:%d\n", F);

	//system("pause");
	//return 0;
}