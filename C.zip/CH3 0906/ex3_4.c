#include <stdio.h>
#include <stdlib.h>

void ex3_4()
{
	float a, b;
	char oper;
	//printf("Please input the expression:(ex:3+2):"); /* ��J�B�⦡ */
	printf("�п�J�Ĥ@��:");
	scanf("%f", &a);
	printf("�п�J�ĤG��:");
	scanf("%f", &b);
	printf("�п�J��N�Ÿ� +-*/:");
	scanf(" %c", &oper);

	//scanf("%d %c %d", &a, &oper, &b);
	switch (oper)
	{
	case '+':
		printf("%.f+%.f=%.f\n", a, b, a + b); /* �L�Xa+b */
		break;
	case '-':
		printf("%.f-%.f=%.f\n", a, b, a - b); /* �L�Xa-b */
		break;
	case '*':
		printf("%.f*%.f=%.f\n", a, b, a*b); /* �L�Xa*b */
		break;
	case '/':
		printf("%.f/%.f=%.3f\n", a, b, a / b); /* �L�Xa%b */
		break;
	default:
		printf("input error!!\n"); /* �L�X�r�� */
	}
	//system("pause");
	//return 0;

	
		
}