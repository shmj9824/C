#include <stdio.h>
#include <stdlib.h>

void Hw4()
{
	int n=5,num=0;
	while (n <= 20)
	{
		printf("%2d*%d=%3d ",n,n,n*n);
		num += n*n;
		n++;
		if (n % 5 == 0)
		{
			printf("\n");
		}
	}

	printf("\n5��20������ƦX��%d\n",num);
	//system("pause");
	//return 0;
}