#include <stdio.h>
#include <stdlib.h>

void Hw1()
{
	int k, p;
	for (k = 1; k <= 5; k++)
	{
		for (p = 1; p <= k; p++)
			printf("%d", p);
		printf("\n");
	}
}