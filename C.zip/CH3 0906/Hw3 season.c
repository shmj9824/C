#include <stdio.h>
#include <stdlib.h>

void Hw3()
{
	int input;
	_Bool flag = 1;
	while (flag)
	{
		printf("�п�J�Ʀr 1~4:");
		scanf("%d", &input);
		switch (input)
		{
		case 1:
			printf("1:�K��\n");
			flag = 0;
			break;
		case 2:
			printf("2:�L��\n");
			flag = 0;
			break;
		case 3:
			printf("3:���\n");
			flag = 0;
			break;
		case 4:
			printf("4:�V��\n");
			flag = 0;
			break;
		default:
			printf("�Э��s��J�Ʀr\n");
			flag = 1;
		}
		//system("pause");
		//return 0;
	}
}