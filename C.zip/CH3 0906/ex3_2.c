#include <stdio.h>
#include <stdlib.h>
void ex3_2()
{
	int num1, num2, larger;
	printf("Please input two integers :\n");
	printf("input Frist integers :");	scanf("%d", &num1);
	printf("input Second integers :");	scanf("%d", &num2);
	num1 > num2 ? (larger = num1) : (larger = num2); /* ����B��l */
	printf("%d greater value \n", larger);
	//system("pause");
	//return 0;
}