#include <stdio.h>
#include <stdlib.h>

void Hw6()
{
	int x, y;
	for (x = 1; x < 10; x++)
	{
		for (y = 1; y < 10; y++)
			printf("%d*%d= %2d ", x, y, x*y);
		printf("\n");
	}
	//systen("pause");
	//return 0;
}