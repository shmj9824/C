#include <stdio.h>
#include <stdlib.h>
 
void ex3_8()
{
	int a, r;
	while (1)
	{
		do
		{
			printf("Input an integer");
			scanf("%d", &a);
		} while (a <= 0);
		printf("The reverse is");
		while (a != 0)
		{
			r = a % 10;		//���l��
			a /= 10;		//���Ӽ�
			printf("%d", r);
		}
		printf("\n\n");
		return 0;
	}
	//system("puase");
	//return 0;
}