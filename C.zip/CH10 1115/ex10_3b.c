#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

void ex10_3b()
{
	char name[20], ans;
	int score;
	printf("�п�J�z���j�W:");
	setbuf(stdin, NULL);
	gets(name);
	do
	{
		printf("\n�п�J�z������:");
		scanf("%d", &score);
		printf("�T�w��?(y/n)");
		ans = _getche();
	} while (ans != 'y');
	puts("\n\n============\n");
	printf("   Name: ");
	puts(name);
	printf("   Score: %d\n", score);
	puts("============\n");
}