#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

char touplow(char);
void ex10_2dc_ex()
{
	char ch,ch1;
	printf("�п�J�@�ӭ^��r��:");
	ch = _getche();
	printf("\n");
	if (isalpha(ch))
	{
		ch1 = touplow(ch);
		printf("���r���ഫ��%c", ch1);
		printf("\n");
	}
	else
		printf("�Э��s��J!\n");
}

char touplow(char a)
{
	if ((a >= 65) && (a<=90) )
		return a + 32;
	else if((a >= 97)&& (a<=122))
		return a - 32;
	else 
		return -1;
}
