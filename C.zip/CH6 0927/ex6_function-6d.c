#include <stdio.h>
#include <stdlib.h>

int sum();
int i = 100, j = 200;
void ex6_function6d()
{
	int total;
	total = sum();
	printf("Total = %d\n", total);
}

int sum()
{
	extern int i, j;
	return (i + j);
}