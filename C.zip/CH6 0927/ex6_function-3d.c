#include <stdio.h>
#include <stdlib.h>

double cube();
void printstar1();
void ex6_function3d()
{
	double a, b, c,ans;
	int n;
	printf("�T�ƥߤ�M�ΦL�P�P\n\n");
	printf("�п�J�T�ӯB�I��:");		scanf("%lf %lf %lf", &a, &b, &c);
	printf("�п�J�P�P��:");		scanf("%d", &n);
	printstar1(n);

	ans = cube(a, b, c);
	printf("�Ӽƥߤ謰%lf %lf %lf\n", a*a*a,b*b*b,c*c*c);
	printf("�T�ƥߤ�M��%lf\n", ans);
	printstar1(n);
}
double cube(double a, double b, double c)
{
	double x, y, z;
	double total;
	x = a*a*a;	y = b*b*b;	z = c*c*c;
	total = x + y + z;
	return total;
}
void printstar1(int n)
{
	int i;
	for (i = 1; i <= n; i++)
	{
		printf("*");
	}
	printf("\n");
}