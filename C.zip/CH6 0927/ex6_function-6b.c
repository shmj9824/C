#include <stdio.h>
#include <stdlib.h>

void increase6b();
void ex6_function6b()
{
	int count;
	printf("Testing storage class << static >>\n");
	for (count = 1; count <= 5; count++)
	{
		printf("#%d call:", count);
		increase6b();
	}
	printf("Testing End!!\n");
}

void increase6b()
{
	static int si = 100;	/* �w�qsi��static�x�s���O�A��Ȭ�100 */
	printf("si = %d\n",++si);
}