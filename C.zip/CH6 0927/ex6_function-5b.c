#include <stdio.h>
#include <stdlib.h>

int factorial5b(int);
void ex6_function5b()
{
	int num;
	printf("Please input a number: ");	scanf("%d", &num);
	printf("Factorial(%d)=%d", num, factorial5b(num));
}

int factorial5b(int n)
{
	int k, total = 1;
	for (k = 1; k <= n; k++)
		total *= k;
	return total;
}