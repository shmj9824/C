#include <stdio.h>
#include <stdlib.h>

void Succe();
int Succeback(int m, int n);
void Hw4_1123()
{
	printf("�O��ƦC\n");
	//Succe();
	Succeback(0, 1);
	//system("pause");
	//return 0;
}

void Succe()         //�D���j��� 
{
	int f0, f1, t, i;
	f0 = 1;        f1 = 1;
	printf("%d,%d", f0, f1);
	for (i = 0; i<8; i++)
	{
		t = f0 + f1;
		f0 = f1;
		f1 = t;
		printf(",%d", t);
	}
	printf("\n");
}

int Succeback(int m, int n)       //���j���
{
	int y;
	y = m + n;
	if (y <= 55)
	{
		printf("%d ", y);
		Succeback(y, m);
	}
	else
		printf("\n����\n");
}