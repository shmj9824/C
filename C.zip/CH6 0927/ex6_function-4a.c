#include <stdio.h>
#include <stdlib.h>

int number;
void output1();
void ex6_function4a()
{
	printf("Please input a number:");	scanf("%d",&number);
	output1();
}	
void output1()
{
	printf("Number is %d\n", number);
}