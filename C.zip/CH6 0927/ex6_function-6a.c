#include <stdio.h>
#include <stdlib.h>

void increase6a();
void ex6_function6a()
{
	int count;
	printf("Testing storage class << auto >>\n");
	for (count = 0; count <= 5; count++)
	{
		printf("#%d call = ",count);
		increase6a();
	}
	printf("Testing end!!\n");

}

void increase6a()
{
	auto ai = 100;	/* �w�qai��auto�x�s���O�A��Ȭ�100 */
	printf("ai = %d\n",++ai);
}