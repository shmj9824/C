#include <stdio.h>
#include <stdlib.h>

void min_3(int, int, int);
void max_3(int, int, int);
void Hw3_maxmin()
{
	int a = 30, b = 40, c = 50;
	printf("�ƭȦ�%d,%d,%d\n", a, b, c);
	min_3(a, b, c);
	max_3(a, b, c);
	//system("pause");
	//return 0;
}

void min_3(int x, int y, int z)
{
	int temp;
	if (x<y)
	{
		if (x<z)
			temp = x;
		else
			temp = z;
	}
	else if (z>y)
		temp = y;
	else
		temp = z;
	printf("�̤p�Ȭ�:%d\n", temp);
}

void max_3(int x, int y, int z)
{
	int temp;
	if (x>y)
	{
		if (x>z)
			temp = x;
		else
			temp = z;
	}
	else if (z<y)
		temp = y;
	else
		temp = z;
	printf("�̤j�Ȭ�:%d\n", temp);
}