#include <stdio.h>
#include <stdlib.h>

int init(int);
int getans(int);
void compare(int, int);
short a = 1;
void Hw2_nember()
{
	int x=0, y=0;
	x = init(x);
	//system("cls");
	while (a)
	{
		y = getans(y);
		compare(x, y);
	}
	//system("pause");
	//return 0;
}
int init(int x)
{
	printf("�п�J����:");  scanf("%d", &x);
	return x;
}

int getans(int y)
{
	printf("�п�J�Ʀr:");  scanf("%d", &y);
	return y;
}

void compare(int o, int p)
{
	if (o == p)
	{
		printf("�q�D���T\n");
		a = 0;
	}
	else
	{
		printf("�q�D���~\n");
		a = 1;
	}
}