#include <stdio.h>
#include <stdlib.h>

void printstar(int);
void ex6_function3b()
{
	int num;
	printf("�A�n�h�֭ӬP�P:");	scanf("%d", &num);
	printstar(num);
}
void printstar(int n)
{
	short i;
	for (i = 0; i < n; i++)
		printf("*");
	printf("\n");
}