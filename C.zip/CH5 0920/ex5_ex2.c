#include <stdio.h>
#include <stdlib.h>

void ex5_ex2()
{
	int score[10][2];
	short i, j;
	for (i = 0; i < 10; i++)
	{
			printf("�п�J%d������:",i+1);	scanf("%d", &score[i][1]);
			//printf("score[%d][%d]=%d\n", i, j, score[i][j]);
	}
	for (i = 0; i < 10; i++)
	{
		printf("%2d: ������:%d ", i + 1,score[i][1]);
		printf("\n");
	}
	
	//system("pause");
	//return 0;
}