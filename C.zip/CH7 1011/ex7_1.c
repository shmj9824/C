#include <stdio.h>
#include <stdlib.h>

#define BEGIN {
#define END }
#define TAB '\t'
#define EVEN(n) (n %2 == 0 ? "����" : "�_��")
void ex7_1()
{
	int *ptr, num = 20;
	ptr = &num;
	printf("num=%d,&num=%x\n", num, &num);
	printf("*ptr=%d,ptr=%x,&ptr=%x\n", *ptr, ptr, &ptr);
}