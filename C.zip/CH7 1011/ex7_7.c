#include <stdio.h>
#include <stdlib.h>

void swap7(int *, int *);
void ex7_7()
{
	int a = 5, b = 20;
	printf("Before swap()...\n");
	printf("a=%d,b=%d\n", a, b);
	swap7(&a, &b);
	printf("After swap()...\n");
	printf("a=%d,b=%d", a, b);
}

void swap7(int *p1, int *p2)
{
	int tmp = *p1;
	*p1 = *p2;
	*p2 = tmp;
}