#include <stdio.h>
#include <stdlib.h>

void test()
{
	/*int a=1234;
	int b, c, d, e;
	b = a / 1000;
	printf("b=%d\n", b);
	c = a / 100 % 10;
	printf("c=%d\n", c);
	d = a % 100 /10;
	printf("d=%d\n", d);
	e = a % 10;
	printf("e=%d\n", e);*/
	int a;
	a = (rand() % 9) + 1;
	printf("The Random Number is %d .\n", a);
	a = (rand() % 9) + 1;
	printf("The Random Number is %d .\n", a);
	a = (rand() % 9) + 1;
	printf("The Random Number is %d .\n", a);
	a = (rand() % 9) + 1;
	printf("The Random Number is %d .\n", a);
}