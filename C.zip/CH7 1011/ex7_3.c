#include <stdio.h>
#include <stdlib.h>

void ex7_3()
{
	int a = 5, b = 10;
	int *ptr1, *ptr2;
	ptr1 = &a;
	ptr2 = &b;
	printf("a=%p, b=%p, \nptr1=%p, ptr2=%p\n", &a, &b, ptr1, ptr2);
	printf("a=%d, b=%d\n", a, b);
	printf("*ptr1=%d, *ptr2=%d\n", *ptr1, *ptr2);
	*ptr1 = 7;
	*ptr2 = 32;
	a = 17;
	ptr1 = ptr2;
	*ptr1 = 9;
	ptr1 = &a;
	a = 64;
	*ptr2 = *ptr1 + 5;
	ptr2 = &a;
	printf("\n");
	printf("a=%p, b=%p, \nptr1=%p, ptr2=%p\n", &a, &b, ptr1, ptr2);
	printf("a=%d, b=%d\n", a, b);
	printf("*ptr1=%2d, *ptr2=%2d\n", *ptr1, *ptr2);
}