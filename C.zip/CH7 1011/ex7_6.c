#include <stdio.h>
#include <stdlib.h>

void swap6(int,int);
void ex7_6()
{
	int a = 5, b = 20;
	printf("Before swap()...\n");
	printf("a=%d,b=%d\n", a, b);
	swap6(a,b);
	printf("After swap()...\n");
	printf("a=%d,b=%d\n", a, b);
}

void swap6(int x, int y)
{
	int tmp = x;
	x = y;
	y = tmp;
}